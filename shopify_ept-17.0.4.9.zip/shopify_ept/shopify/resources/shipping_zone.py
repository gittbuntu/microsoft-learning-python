from ..base import ShopifyResource


class ShippingZone(ShopifyResource):
    pass
